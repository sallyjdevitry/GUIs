import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polyline;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.control.TextField;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.io.File;
import java.util.Scanner;

public class Main extends Application {
    String phrase;
    int i = 0;
    int startX = 50;
    int endX = 70;
    int counter = 0;
    List<String> phrasesList = new ArrayList<>();
    int changer = 0;
    int correctCount = 0;
    int numberOfSpaces = 0;

    public static void main(String[] args) {
        launch(args);
    }

    public void start(Stage primaryStage) {
        counter = 0;
        numberOfSpaces = 0;

        //getting the phrases into a list
        try {
            Scanner scanner = new Scanner(new File("src/phrases.txt"));
            while (scanner.hasNextLine()) {
                phrasesList.add(scanner.nextLine());
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        //getting a random phrase for the round
        phrase = getRandomPhrase(phrasesList);


        //draw gallow
        Pane pane = new Pane();
        pane.setBackground(new Background(new BackgroundFill(Color.LIGHTCYAN, CornerRadii.EMPTY, Insets.EMPTY)));
        Polyline gallowLines = new Polyline();
        pane.getChildren().add(gallowLines);
        gallowLines.setStroke(Color.BLACK);
        ObservableList<Double> list = gallowLines.getPoints();
        double x1 = 60.0D;
        double y1 = 250.0D;
        double y2 = 40.0D;
        double x3 = 170.0D;
        list.addAll(new Double[]{x1, y1, x1, y2, x3, y2, x3, y1 * 0.3D});


        Arc arc = new Arc(60.0D, 262.0D, 50.0D, 12.0D, 0.0D, 180.0D);
        arc.setFill(Color.WHITE);
        arc.setType(ArcType.OPEN);
        arc.setStroke(Color.BLACK);
        pane.getChildren().add(arc);

        //textbox
        TextField letter = new TextField();
        Label label1 = new Label("Enter your guess(lowercase):");
        Button guessButton = new Button("guess!");
        VBox vb = new VBox();
        vb.setPadding(new Insets(40, 5, 5, 300));
        vb.getChildren().addAll(label1, letter, guessButton);
        pane.getChildren().add(vb);

        phrase = phrase.toLowerCase();
        System.out.println(phrase);
        changer = 0;

        guessButton.setOnAction(event -> {
            Label isCorrect = new Label();

            if (letter.getText().isEmpty()){
                System.out.print(" ");
            }

            else if (phrase.contains(letter.getText())) {

                int indToPrint = phrase.indexOf(letter.getText());

                while (indToPrint >= 0) {
                    Text toPrint = new Text(letter.getText());

                    toPrint.setFont(Font.font(30));
                    toPrint.setX(50 + (30 * indToPrint));
                    toPrint.setY(550);
                    pane.getChildren().add(toPrint);
                    correctCount+=1;

                    indToPrint = phrase.indexOf(letter.getText(), indToPrint + 1);


                }

                isCorrect.setText(letter.getText() + " is correct!");
                isCorrect.setTextFill(Color.GREEN);
                vb.getChildren().add(isCorrect);
                letter.clear();


                if (correctCount == (phrase.length()-numberOfSpaces)){
                    Text winner1 = new Text("HOORAY!");
                    Text winner2 = new Text("YOU WIN.");
                    Button playAgainBt = new Button("Play Again");
                    Button exitBt = new Button("Exit");

                    playAgainBt.setLayoutX(750);
                    playAgainBt.setLayoutY(230);

                    exitBt.setLayoutX(850);
                    exitBt.setLayoutY(230);

                    winner1.setFill(Color.GREEN);
                    winner2.setFill(Color.GREEN);
                    winner1.setFont(Font.font(100));
                    winner2.setFont(Font.font(100));
                    winner1.setX(600);
                    winner1.setY(100);
                    winner2.setX(600);
                    winner2.setY(200);
                    pane.getChildren().add(winner1);
                    pane.getChildren().add(winner2);
                    pane.getChildren().add(playAgainBt);
                    pane.getChildren().add(exitBt);

                        Image congratsGif = new Image("https://cdn.vox-cdn.com/uploads/chorus_asset/file/6117859/gatsby.0.gif");
                        ImageView imageView = new ImageView(congratsGif);
                        imageView.setX(710);
                        imageView.setY(265);
                        imageView.setFitHeight(210);
                        imageView.setFitWidth(355);
                        pane.getChildren().add(imageView);


                    //offer to play the game again
                    playAgainBt.setOnAction(event1 -> {
                        pane.getChildren().clear();
                        vb.getChildren().clear();
                        correctCount = 0;
                        counter = 0;
                        numberOfSpaces = 0;
                        start(primaryStage);});


                    exitBt.setOnAction(event1 -> {System.exit(1);});

                }



            } else {

                vb.getChildren().remove(isCorrect);
                Text isIncorrect = new Text(letter.getText() + " is Incorrect:(");
                isIncorrect.setFill(Color.RED);
                isIncorrect.setX(420);
                isIncorrect.setY(122 + changer);
                changer += 17;

                pane.getChildren().add(isIncorrect);
                letter.clear();
                counter += 1;
            }

            if (counter == 1) {
                Circle circle = new Circle(170.0D, 84.0D, 22.0D, Color.WHITE);
                circle.setStroke(Color.BLACK);
                circle.setStrokeWidth(4);
                pane.getChildren().add(circle);
                vb.getChildren().remove(isCorrect);

            } else if (counter == 2) {
                Line torso = new Line(170, 106, 170, 190);
                try {
                    Image byuImg = new Image(new FileInputStream("src/byuShirt.png"));
                    ImageView imageView = new ImageView(byuImg);
                    imageView.setX(137);
                    imageView.setY(106);
                    imageView.setFitHeight(75);
                    imageView.setFitWidth(72);
                    pane.getChildren().add(imageView);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                torso.setStroke(Color.BLACK);
                torso.setStrokeWidth(4);
                pane.getChildren().add(torso);
            } else if (counter == 3) {
                Line rightArm = new Line(170.0D, 120.0D, 220.0D, 135.0D);
                rightArm.setStroke(Color.BLACK);
                rightArm.setStrokeWidth(4);
                pane.getChildren().add(rightArm);
            } else if (counter == 4) {
                Line leftArm = new Line(170.0D, 120.0D, 120.0D, 135.0D);
                leftArm.setStroke(Color.BLACK);
                leftArm.setStrokeWidth(4);
                pane.getChildren().add(leftArm);
            } else if (counter == 5) {
                Line rightLeg = new Line(170.0D, 190D, 204.0D, 210.0D);
                rightLeg.setStroke(Color.BLACK);
                rightLeg.setStrokeWidth(4);
                pane.getChildren().add(rightLeg);
            } else if (counter == 6) {
                Line leftLeg = new Line(170D, 190D, 136.0D, 210.0D);
                leftLeg.setStroke(Color.BLACK);
                leftLeg.setStrokeWidth(4);
                pane.getChildren().add(leftLeg);
                Text loser1 = new Text("SORRY,");
                Text loser2 = new Text("YOU LOSE.");
                Button playAgainBt = new Button("Play Again");
                Button exitBt = new Button("Exit");

                playAgainBt.setLayoutX(750);
                playAgainBt.setLayoutY(230);

                exitBt.setLayoutX(850);
                exitBt.setLayoutY(230);

                loser1.setFill(Color.RED);
                loser2.setFill(Color.RED);
                loser1.setFont(Font.font(100));
                loser2.setFont(Font.font(100));
                loser1.setX(600);
                loser1.setY(100);
                loser2.setX(600);
                loser2.setY(200);
                pane.getChildren().add(loser1);
                pane.getChildren().add(loser2);
                pane.getChildren().add(playAgainBt);
                pane.getChildren().add(exitBt);

                Image sadGif = new Image("https://media.tenor.com/images/5c8199d6140241582ecf8fad2a61a354/tenor.gif");
                ImageView imageView = new ImageView(sadGif);
                imageView.setX(710);
                imageView.setY(265);
                imageView.setFitHeight(200);
                imageView.setFitWidth(200);
                pane.getChildren().add(imageView);


                //offer to play the game again
                playAgainBt.setOnAction(event1 -> {
                    pane.getChildren().clear();
                    vb.getChildren().clear();
                    counter = 0;
                    correctCount = 0;
                    numberOfSpaces = 0;
                    start(primaryStage);});


                exitBt.setOnAction(event1 -> {System.exit(1);});

            }

        });


        i = 0;
        int startX = 50;
        int endX = 70;


        //outputting the blank lines of the phrase
        while (i < phrase.length()) {

            if (phrase.charAt(i)!= ' ') {

                Line underlines = new Line(startX, 550, endX, 550);
                underlines.setStroke(Color.BLACK);
                pane.getChildren().add(underlines);

            }
            else if (phrase.charAt(i)== ' ') {
                numberOfSpaces += 1;
            }

            i++;
            startX += 30;
            endX += 30;
        }

        Scene scene = new Scene(pane, 1200.0D, 600.0D);
        scene.setFill(Color.LIGHTCYAN);
        primaryStage.setTitle("Hangman!!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }


    //functions


    public String getRandomPhrase(List list){
        int getterInd = (int)(Math.random()*25);

        String string = (list.get(getterInd)).toString();
        return string;
    }

}


